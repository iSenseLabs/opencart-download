/////////////////////////////////
///       OpenCart V1.5.x     ///
///  http://www.opencart.com  ///
/////////////////////////////////


-------
INSTALL
-------

Go Here for the current install instructions:

  http://www.opencart.com/index.php?route=documentation/documentation&path=4


-------
UPGRADE
-------

Go Here for the current upgrade instructions:

  http://www.opencart.com/index.php?route=documentation/documentation&path=98



EOF